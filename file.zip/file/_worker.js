/**
 * Cloudflare Pages Worker - 全封闭 UUID 鉴权版
 * 
 * 安全策略：
 * 1. 所有操作 (读/写/删) 必须提供正确的 X-API-Key (UUID)。
 * 2. 不绑定 IP、不绑定 Referer、不绑定特定 URL 路径逻辑。
 * 3. KV 绑定变量名必须为: webhome
 */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // 🔐【核心配置】在此设置你的唯一密钥 (UUID)
    // ⚠️ 请务必替换为你自己生成的强随机 UUID
    const SECRET_KEY = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"; 

    // --- 路由拦截 ---
    // 只处理 /api/ 开头的请求，其他静态资源直接放行
    if (!url.pathname.startsWith('/api/')) {
      return null; 
    }

    // --- 提取 KV Key ---
    // URL 路径仅作为数据键名 (Key)，例如 /api/site_config -> key = "site_config"
    const kvKey = url.pathname.replace('/api/', '') || 'default';

    const method = request.method;

    // --- 1. 处理 CORS 预检 (OPTIONS) ---
    // 浏览器跨域必先发送此请求，此时无需验证 UUID，但必须返回允许的头
    if (method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*', 
          'Access-Control-Allow-Methods': 'GET, PUT, POST, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-API-Key', // 必须声明允许 X-API-Key
          'Access-Control-Max-Age': '86400',
        },
      });
    }

    // --- 2. 强制 UUID 鉴权 (针对 ALL 方法) ---
    // 现在的逻辑：不管是读还是写，只要不是 OPTIONS，都必须验钥匙
    const providedKey = request.headers.get('X-API-Key');

    if (!providedKey || providedKey !== SECRET_KEY) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Unauthorized', 
          message: 'Access Denied: Valid UUID (X-API-Key) is required for ALL operations.' 
        }), 
        {
          status: 401,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*' 
          }
        }
      );
    }

    // --- 3. 执行 KV 业务逻辑 (此时已确认身份合法) ---
    try {
      // ✅ GET: 读取数据
      if (method === 'GET') {
        const value = await env.webhome.get(kvKey);
        
        if (value === null) {
          return new Response(JSON.stringify({ success: false, message: 'Key not found' }), {
            status: 404,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
          });
        }

        return new Response(value, {
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*' 
          },
        });
      }

      // ✅ PUT / POST: 写入/更新数据
      if (method === 'PUT' || method === 'POST') {
        const contentType = request.headers.get('Content-Type') || '';
        if (!contentType.includes('application/json')) {
          return new Response(JSON.stringify({ success: false, error: 'Content-Type must be application/json' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
          });
        }

        const body = await request.json();
        await env.webhome.put(kvKey, JSON.stringify(body));

        return new Response(JSON.stringify({ 
          success: true, 
          message: 'Data saved successfully', 
          key: kvKey 
        }), {
          status: 200,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*' 
          },
        });
      }

      // ✅ DELETE: 删除数据
      if (method === 'DELETE') {
        await env.webhome.delete(kvKey);

        return new Response(JSON.stringify({ 
          success: true, 
          message: 'Data deleted successfully', 
          key: kvKey 
        }), {
          status: 200,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*' 
          },
        });
      }

      // ❌ 不支持的方法
      return new Response(JSON.stringify({ success: false, error: 'Method not allowed' }), {
        status: 405,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });

    } catch (error) {
      console.error('Worker Error:', error);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Internal Server Error', 
        details: error.message 
      }), {
        status: 500,
        headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*' 
        }
      });
    }
  },
};